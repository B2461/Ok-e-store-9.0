
export const firebaseConfig = {
  apiKey: "AIzaSyAHiRcSSwQXluJ80HSgHey7tOcpUdWfUSM",
  authDomain: "ok-e-store-90.firebaseapp.com",
  projectId: "ok-e-store-90",
  storageBucket: "ok-e-store-90.firebasestorage.app",
  messagingSenderId: "223083943964",
  appId: "1:223083943964:web:3b7be3c9f55fd402d667d9"
};
