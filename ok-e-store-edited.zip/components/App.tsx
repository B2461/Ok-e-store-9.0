    const ProfileButton: React.FC = () => {
        const { isAuthenticated, currentUser, showAuth, t } = useAppContext();
        const navigate = useNavigate();
    
        const handleClick = () => {
            if (isAuthenticated) {
                navigate('/profile');
            } else {
                showAuth();
            }
        };
    
        return (
            <button onClick={handleClick} className="flex flex-col items-center justify-center w-14 py-1 rounded-lg hover:bg-white/10 transition-colors duration-300">
                <div className="w-7 h-7 rounded-full bg-white/10 border border-white/20 flex items-center justify-center overflow-hidden">
                    {isAuthenticated && currentUser?.profilePicture ? (
                        <img src={currentUser.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                    )}
                </div>
                 <span className="text-xs font-medium mt-1 text-white">{isAuthenticated ? (currentUser?.name?.split(' ')[0] || t('profile')) : t('login')}</span>
            </button>
        );
    };