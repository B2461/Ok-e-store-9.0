import React from "react";

const Header: React.FC = () => {
    return (
        <header 
            className="w-full flex items-center justify-between px-4 py-2 bg-white shadow-md"
            style={{ position: "sticky", top: 0, zIndex: 1000 }}
        >
            <img 
                src="/logo.png" 
                alt="OK E-store Logo"
                style={{
                    width: 55,
                    height: 55,
                    borderRadius: "50%"
                }}
            />
        </header>
    );
};

export default Header;
